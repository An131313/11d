package hello;

public class hallo {

}
