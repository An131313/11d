package input06;

public class Zad2 {
	double wavelength;
	 System.out.println("Enter wavelength");
	 
}
