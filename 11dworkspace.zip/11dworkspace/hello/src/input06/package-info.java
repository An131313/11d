/**
 * 
 */
/**
 * @author smg192E
 *
 */
package input06;